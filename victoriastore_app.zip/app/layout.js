import './globals.css';

export const metadata = {
  title: 'VictoriaStore',
  description: 'Sklep online VictoriaStore',
};

export default function RootLayout({ children }) {
  return (
    <html lang="pl">
      <body>{children}</body>
    </html>
  );
}