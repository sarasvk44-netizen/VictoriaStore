export default function Home() {
  const tiles = [
    { label: "Nowości", icon: "✨" },
    { label: "Produkty", icon: "🛍️" },
    { label: "Promocje", icon: "🎁" },
    { label: "Kontakt", icon: "📞" },
  ];

  return (
    <main className="min-h-screen max-w-4xl mx-auto p-6">
      <header className="flex justify-center my-6">
        <h1 className="text-4xl font-semibold text-lilac" style={{fontFamily:"cursive"}}>
          VictoriaStore
        </h1>
      </header>

      <section className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8">
        {tiles.map(t => (
          <a key={t.label} href="#" className="rounded-2xl border-2 border-lilac p-6 text-center font-medium hover:bg-lilac hover:text-white transition">
            <div className="text-3xl mb-2">{t.icon}</div>
            <div>{t.label}</div>
          </a>
        ))}
      </section>
    </main>
  );
}